# survNMA 1.1-1 (2025-01-30)

- first version released on CRAN
