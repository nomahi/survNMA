# survNMA 2.1-1 (2025-01-30)

- Some data editing functions are added.

# survNMA 1.1-1 (2025-01-23)

- first version released on GitHub
