combine2 <- function(data1, data2){

	data1 <- data.frame(data1)
	data2 <- data.frame(data2)

	A1 <- as.numeric(factor(data1$studlab))
	A2 <- data1$treat1
	A3 <- data1$treat2
	A4 <- data1$TE
	A5 <- data1$seTE
	# A6 <- data1$n1
	# A7 <- data1$n2
	
	B1 <- as.numeric(factor(data2$studlab)) + max(A1)
	B2 <- data2$treat1
	B3 <- data2$treat2
	B4 <- data2$TE
	B5 <- data2$seTE
	# B6 <- data2$n1
	# B7 <- data2$n2
	
	studlab <- c(A1,B1)
	treat1 <- c(A2,B2)
	treat2 <- c(A3,B3)
	TE <- c(A4,B4)
	seTE <- c(A5,B5)
	# n1 <- c(A6,B6)
	# n2 <- c(A7,B7)
	
	# R <- data.frame(studlab,treat1,treat2,TE,seTE,n1,n2)
	R <- data.frame(studlab,treat1,treat2,TE,seTE)
  
	return(R)

}
