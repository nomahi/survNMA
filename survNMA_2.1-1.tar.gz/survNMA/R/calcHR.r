calcHR <- function(d1,n1,d0,n0){

	A <- d1
	B <- n1 - d1
	C <- d0
	D <- n0 - d0

	P1 <- d1/n1
	P0 <- d0/n0

	TE <- log(-log(1-P1)) - log(-log(1-P0))

	J1 <- 1/((P1-1)*log(1-P1))
	J2 <- P1*(1-P1)/n1
	J3 <- 1/((P0-1)*log(1-P0))
	J4 <- P0*(1-P0)/n0

	V <- J1*J1*J2 + J3*J3*J4
	seTE <- sqrt(V)
	
	return(list(TE=TE,seTE=seTE))

}
