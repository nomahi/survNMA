calcse <- function(se1,se2,n1,n2,n0){

	A1 <- se1*se1 + se2*se2
	A2 <- 1/n1 + 1/n2
	A3 <- 1/n1 + 1/n2 + 2/n0

	return( sqrt( A1*A2/A3 ) )

}
